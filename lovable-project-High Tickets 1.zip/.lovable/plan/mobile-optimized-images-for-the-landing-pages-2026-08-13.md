# Mobile-optimized images for the landing pages

## Problem
The hero and unlock-card images are wide (landscape) art. On phones they are cropped into a 4:3 / 3:2 box, so the most persuasive parts (the tired worker vs. the earnings screen, the $1,230.45 commission) get cut off at the edges.

## Solution
Generate dedicated mobile (portrait-framed) versions of both images and serve them only on small screens, keeping the existing desktop art untouched.

### 1. New image assets
- `src/assets/hero-split-mobile.jpg` (1024x1280, 4:5) — vertical split: top half a tired night-shift worker on a phone, bottom half the same person relaxed at a laptop with a rising earnings dashboard. Composition centered so nothing important sits near the edges.
- `src/assets/unlock-card-mobile.jpg` (1024x1024, 1:1) — phone screen showing a $1,230.45 commission notification with a locked/blurred "private system" panel, subject centered.

### 2. Responsive swap
In `src/components/quiet-ledger/LedgerPage.tsx`, wrap both `<img>` tags in `<picture>`:
- `<source media="(max-width: 639px)" srcSet={mobileImage} />` then the existing `<img>` as desktop fallback.
- Mobile aspect ratios: hero `aspect-[4/5]`, unlock card `aspect-square`; desktop keeps `sm:aspect-[16/9]` and `sm:aspect-[3/2]`.
- Keep `loading="eager"`, `fetchPriority="high"`, `decoding="async"` so load stays in the 1–2s window.
- Overlay gradient, badges and caption stay as-is; only padding is checked so text does not collide with the taller image.

### 3. Verify
Screenshot `/deep` and `/shallow` at 390px width and at desktop width to confirm nothing important is cropped and the CTA still sits above the fold area as before.

## Notes
No backend, tracking, locker or admin logic changes.
