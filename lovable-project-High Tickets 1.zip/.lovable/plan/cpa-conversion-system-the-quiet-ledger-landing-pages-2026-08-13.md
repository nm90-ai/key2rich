# CPA conversion system + The Quiet Ledger landing pages

Backend tracking, postback routing, two locked article variants (`/deep`, `/shallow`), and a private analytics dashboard.

## Backend

Lovable Cloud is not enabled on this project yet, so the first step is turning it on (this provisions the database and auth).

Database tables, exactly as specified: `visits` (click_id, source, page_variant, unique subid) and `conversions` (subid, source, page_variant, payout, unique txid, status), plus the four indexes. Both tables get grants; row-level security allows anonymous inserts into `visits` only, all reads restricted to the admin.

### Postback endpoint

This project runs on TanStack Start, so the postback lives in the app itself instead of a Deno edge function. Same query contract, same logic, always returns HTTP 200 so CPAGrip never retries:

```text
https://<your-app>/api/public/postback-router?subid=...&payout=...&txid=...
```

Logic: split `subid` into `source_variant_clickid`, take the click id verbatim (decoded once, never rebuilt), upsert the conversion on `txid`, then route by source:

- `tb` (TimeBucks): HMAC-SHA256 hex of the exact click id with `TIMEBUCKS_SECRET`, call `https://webhooks.timebucks.com/taskapprove/?sessionid=<clickid>&signature=<sig>`; 200 or 409 = credited, 400/401 = failed.
- `coin` / `fc`: fetch the template from `COINTIPLY_POSTBACK_TEMPLATE` / `FREECASH_POSTBACK_TEMPLATE`, substituting `{clickid}` and `{payout}`; any OK response = credited.

Finally update the conversion's status. Missing secrets simply leave the conversion `pending` rather than crashing.

Secrets to add (I'll open the secure form): `TIMEBUCKS_SECRET`, `COINTIPLY_POSTBACK_TEMPLATE`, `FREECASH_POSTBACK_TEMPLATE`. Locker ID `1908703` is fixed in code.

## `/deep` — The Quiet Ledger

Cream `#FAF6F1`, ink `#1C1917`, orange accent `#C2410C`, Playfair Display headlines, Inter body at 16-17px / 1.7, mobile-first. Header with "The Quiet Ledger" and a "Free premium read" pill.

On load: read `click_id` and `source` (`tb`/`coin`/`fc`, default `direct`), build `subid = source_deep_<encoded click_id>`, insert the visit ignoring duplicates, and store the subid in localStorage.

Hero with the tag, headline, subtitle, byline, and a generated photoreal split-screen image (tired night delivery rider vs. relaxed at laptop with green chart) plus caption. Then the full article text as supplied, ending after the two visible bullets of the "hidden advantage" section. Peach teaser box, unlock card with its own generated image, and a sticky bottom orange unlock bar that appears after the hero.

Footer with the auto-updating year, the sponsored/affiliate disclosures, and a privacy policy link. Title tag = H1, meta description = subtitle, images lazy-loaded.

### Locker behavior

The CPAGrip script is never present on page load. Clicking any unlock button injects `https://optilinklock.com/script_include.php?id=1908703&subid=<subid>` into `#locker-container`, preserving the `lck` guard, the adblock `top.location` redirect, and the noscript fallback. Hidden content is revealed only on a genuine CPAGrip completion signal (completion callback / success param / completion cookie), never on overlay close — the reveal state persists per subid in localStorage.

## `/shallow`

Identical page, three differences: `page_variant = "shallow"`, the lock point moves up to just after "…a simple system that keeps working even when you're not.", the new teaser copy, and a blurred, padlocked preview list of the four upcoming section titles above the unlock card. Shared components keep both variants in sync.

## `/admin`

Sign-in page plus a protected dashboard, restricted to `nayeemul1206@gmail.com` (enforced in the database policies and server-side, not just in the UI). Same design system.

- KPI cards: total visits, total conversions, total credited payout, overall conversion rate.
- Filter tabs for source (tb / coin / fc / all) and variant (deep / shallow / all).
- A/B table grouped by source + variant: visits, conversions, conversion rate, payout.
- Latest 50 conversions with colored status badges and truncated subid.
- Logout button.

## Technical notes

- Postback is a public server route under `src/routes/api/public/`; all writes use the service-role client inside the handler.
- Visit inserts go through a public server function (no anon write policy needed beyond the insert path).
- Admin reads go through authenticated server functions with an email check.
- Shared article components live in `src/components/quiet-ledger/`; both routes are separate files with their own `head()` metadata.
- After publishing, I'll print the final postback URL for CPAGrip.
