# Update TimeBucks secret

The user has provided a new `TIMEBUCKS_SECRET` value. Update the project secret so the postback endpoint can re-sign TimeBucks click IDs with the new key.

## Steps

1. Call `secrets--update_secret` for `TIMEBUCKS_SECRET` so the new value is stored in the encrypted secret store.
2. Verify the secret is updated by reading the secret list, then confirm the postback route still reads the secret at runtime.
